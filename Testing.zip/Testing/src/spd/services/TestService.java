package spd.services;

import java.util.List;

import spd.dao.TestDao;
import spd.domain.CurrTest;
import spd.domain.Test;

public class TestService {
	public static TestService instance;

	/**
	 * @return the instance
	 */
	public static TestService getInstance() {
		return instance;
	}

	/**
	 * @param instance the instance to set
	 */
	public void setInstance(TestService instance) {
		TestService.instance = instance;
	}

	private TestDao testDao;

	/**
	 * @return the testDao
	 */
	public TestDao getTestDao() {
		return testDao;
	}

	/**
	 * @param testDao the testDao to set
	 */
	public void setTestDao(TestDao testDao) {
		this.testDao = testDao;
	}
	
	public List<Test> getTests(){

		List<Test> list = testDao.getTests();
		return list;
	}
	
	public void setCurrTest(Integer userID, Integer testID, Integer questionID, Integer answerID, String sessionID){
		CurrTest currTest = new CurrTest();
		currTest.setUserId(userID);
		currTest.setTestId(testID);
		currTest.setQuestionId(questionID);
		if (answerID!=0) {
			currTest.setAnswerId(answerID);
		}
		currTest.setSessionID(sessionID);
		testDao.setCurrentTest(currTest);
	}
	
	public List<CurrTest> getCurrTest(Integer userID, String sessionID, Integer testID){
		List<CurrTest> list = testDao.getCurrTest(userID, sessionID, testID);
		return list;
	}

	public void clearCurrTest(Integer userID, String sessionID, Integer testID){
		testDao.clearCurrTest(userID, sessionID, testID);
	}
}
