package spd.services;

import org.springframework.beans.factory.annotation.Autowired;
import spd.dao.UserDao;
import spd.domain.User;

public class UserService {
	public static UserService instance;

	/**
	 * @return the instance
	 */
	public static UserService getInstance() {
		return instance;
	}

	/**
	 * @param instance the instance to set
	 */
	public void setInstance(UserService instance) {
		UserService.instance = instance;
	}

	private UserDao userDao;
	
	/**
	 * @return the userDao
	 */
	public UserDao getUserDao() {
		return userDao;
	}

	/**
	 * @param userDao the userDao to set
	 */
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public void saveUser(String username, String password, String userrole){
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setUserRole(userrole);
		userDao.saveUser(user);
	}
	
	public boolean loginUser(String username, String password){
		if (null == userDao.getUser(username, password)){
			return false;
		} else {
			return true;
		}
	}
	
	public Integer getUserId(String username, String password){
		User user = userDao.getUser(username, password); 
		return (Integer) user.getId();
	}

	public String getUserRole(String username, String password){
		User user = userDao.getUser(username, password);
		return (String) user.getUserRole();
	}


}
