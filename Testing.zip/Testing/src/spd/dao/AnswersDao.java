package spd.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import spd.domain.Answers;

public class AnswersDao extends HibernateDaoSupport{
	
	@SuppressWarnings("unchecked")
	public List<Answers> getAnswers(int question_id){
		Criteria criteria = getSession().createCriteria(Answers.class)
										.add(Restrictions.eq("questionId", question_id));
		return criteria.list();
	}
	
	public Answers getCurrAnswer(Integer answerID){
		Criteria criteria = getSession().createCriteria(Answers.class)
										.add(Restrictions.eq("id", answerID));
		return (Answers) criteria.uniqueResult();
	}
	
	public Answers getCorrectAnswer(Integer questionID){
		Criteria criteria = getSession().createCriteria(Answers.class)
										.add(Restrictions.eq("questionId", questionID))
										.add(Restrictions.eq("correct", 1));
		return (Answers) criteria.uniqueResult();
	}
}
