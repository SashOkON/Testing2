package spd.dao;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import spd.domain.User;

public class UserDao extends HibernateDaoSupport{
	public void saveUser(User user){
		getHibernateTemplate().save(user);
	}

	public User getUser(String username, String password) {
		Criteria criteria = getSession().createCriteria(User.class)
										.add(Restrictions.eq("username", username))
										.add(Restrictions.eq("password", password));
		return (User) criteria.uniqueResult();
	}
	public String getUserrole(Integer userId) {
		Criteria criteria = getSession().createCriteria(User.class)
				.add(Restrictions.eq("id", userId));
		return (String) criteria.uniqueResult();
	}
}