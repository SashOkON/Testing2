package spd.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import spd.domain.CurrTest;
import spd.domain.Test;

public class TestDao extends HibernateDaoSupport{
	
	@SuppressWarnings("unchecked")
	public List<Test> getTests() {
		Criteria criteria = getSession().createCriteria(Test.class);
		return criteria.list();
	}
	
	public void setCurrentTest(CurrTest currTest){
		getHibernateTemplate().save(currTest);
	}
	
	@SuppressWarnings("unchecked")
	public List<CurrTest> getCurrTest(Integer userID, String sessionID, Integer testID){
		Criteria criteria = getSession().createCriteria(CurrTest.class)
									   .add(Restrictions.eq("userId", userID))
									   .add(Restrictions.eq("testId", testID))
									   .add(Restrictions.eq("sessionID", sessionID));
		return criteria.list();
	}
	
	public void clearCurrTest(Integer userID, String sessionID, Integer testID){
		String sql = "Delete from CURRTEST " +
					 "where user_id = :userID " +
					 "and test_id = :testID " +
					 "and sessionID = :sessionID";
		SQLQuery query = getSession().createSQLQuery(sql);
		query.setParameter("testID", testID)
			 .setParameter("userID", userID)
			 .setParameter("sessionID", sessionID);
		query.executeUpdate();
	}
}