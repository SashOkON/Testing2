package spd.dao;

import java.util.ArrayList;
import org.hibernate.SQLQuery;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import spd.domain.Question;

public class QuestionsDao extends HibernateDaoSupport{
	
	@SuppressWarnings("unchecked")
	public ArrayList<Object> genQuesId(int testID){
		String sql = "Select QUESTIONS.ID from QUESTIONS where QUESTIONS.TEST_ID = :testid";
		SQLQuery query = getSession().createSQLQuery(sql);
		query.setParameter("testid", testID);
		return (ArrayList<Object>) query.list();
	}

	public Question getQuestion(Integer id) {
		return (Question) getSession().get(Question.class, id);
	}
}