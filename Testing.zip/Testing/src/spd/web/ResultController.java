package spd.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import spd.services.AnswersService;
import spd.services.QuestionsService;
import spd.services.TestService;

import javax.servlet.http.HttpServletRequest;

@Controller
public class ResultController {
	
	@RequestMapping("/result")
	public ModelAndView Result(HttpServletRequest request,
							   @RequestParam(required=true) Integer res) throws Exception{
		ModelAndView mav = new ModelAndView("result");
		int userID =(Integer) request.getSession().getAttribute("userID");
		int testID = (Integer) request.getSession().getAttribute("testID");
		int questionID = (Integer) request.getSession().getAttribute("questionID");
		String sessionID = request.getSession().getId();
		TestService.getInstance().setCurrTest(userID, testID, questionID, res, sessionID);
		QuestionsService.getInstance().clearMap(request.getSession().getId());
		mav.addObject("questions", QuestionsService.getInstance().showQuestion(userID, sessionID, testID));
		mav.addObject("currAnswers", AnswersService.getInstance().getCurrAnswer(userID, sessionID, testID));
		mav.addObject("correctAnswers", AnswersService.getInstance().getCorrectAnswer(userID, sessionID, testID));
		mav.addObject("result",  AnswersService.getInstance().result(userID, sessionID, testID));
		TestService.getInstance().clearCurrTest(userID, sessionID, testID);
		return mav;
	}
}
