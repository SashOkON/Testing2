package spd.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import spd.domain.User;
import spd.services.TestService;
import spd.services.UserService;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by 555 on 04.04.2015.
 */
@Controller
public class AdminController {
    @RequestMapping("/admin")
    public ModelAndView edit () throws Exception {
        ModelAndView mav = new ModelAndView("admin");
        return mav;
    }

}
